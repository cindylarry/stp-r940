#!/bin/bash

make clean
./scripts/configure --with-prefix=`pwd`/install --with-cryptominisat2 && make OPTIMIZE=-O2 install -j `grep -c processor /proc/cpuinfo`

STPDIR=`pwd`/install



