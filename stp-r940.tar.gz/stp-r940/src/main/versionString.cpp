#include <string>
namespace BEEV{extern const std::string version=" ";}
