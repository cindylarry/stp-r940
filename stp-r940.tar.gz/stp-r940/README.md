# stp-r940

This is NOT an upstream STP. But it is needed for old symbolic execution engine. The submitted version fixed some parser problem, and remove compilation flag m32 to work on x64 platform.
